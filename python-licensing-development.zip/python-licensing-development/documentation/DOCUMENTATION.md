# Documentation
## Server Infrastructure
![./src/server-infrastructure.png](./src/server-infrastructure.png)

## Communication
![./src/communication.png](./src/communication.png)