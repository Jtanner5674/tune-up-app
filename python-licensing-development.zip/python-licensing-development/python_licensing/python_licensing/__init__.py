"""
This module provides the `licensed` decorator for the python_licensing package.
"""

from .python_licensing import licensed

__all__ = ['licensed']
